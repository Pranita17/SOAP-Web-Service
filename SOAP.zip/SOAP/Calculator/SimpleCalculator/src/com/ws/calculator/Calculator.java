package com.ws.calculator;

public class Calculator {

	public int addition(int input1, int input2)
	{
		return input1 + input2;	
	}
	public int substraction(int input1,int input2)
	{
		return input1 - input2;	
	}
	public int multiplication(int input1,int input2)
	{
		return input1 * input2;	
	}
	public int division(int input1,int input2)
	{
		return input1 / input2;	
	}
}
