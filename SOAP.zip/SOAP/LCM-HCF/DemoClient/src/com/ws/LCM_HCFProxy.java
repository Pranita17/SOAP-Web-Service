package com.ws;

public class LCM_HCFProxy implements com.ws.LCM_HCF {
  private String _endpoint = null;
  private com.ws.LCM_HCF lCM_HCF = null;
  
  public LCM_HCFProxy() {
    _initLCM_HCFProxy();
  }
  
  public LCM_HCFProxy(String endpoint) {
    _endpoint = endpoint;
    _initLCM_HCFProxy();
  }
  
  private void _initLCM_HCFProxy() {
    try {
      lCM_HCF = (new com.ws.LCM_HCFServiceLocator()).getLCM_HCF();
      if (lCM_HCF != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)lCM_HCF)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)lCM_HCF)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (lCM_HCF != null)
      ((javax.xml.rpc.Stub)lCM_HCF)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ws.LCM_HCF getLCM_HCF() {
    if (lCM_HCF == null)
      _initLCM_HCFProxy();
    return lCM_HCF;
  }
  
  public int gcd(int a, int b) throws java.rmi.RemoteException{
    if (lCM_HCF == null)
      _initLCM_HCFProxy();
    return lCM_HCF.gcd(a, b);
  }
  
  public int hcf(int a, int b) throws java.rmi.RemoteException{
    if (lCM_HCF == null)
      _initLCM_HCFProxy();
    return lCM_HCF.hcf(a, b);
  }
  
  public int lcm(int a, int b) throws java.rmi.RemoteException{
    if (lCM_HCF == null)
      _initLCM_HCFProxy();
    return lCM_HCF.lcm(a, b);
  }
  
  
}