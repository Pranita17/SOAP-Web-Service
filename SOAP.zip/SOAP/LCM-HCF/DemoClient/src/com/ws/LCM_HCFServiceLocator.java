/**
 * LCM_HCFServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ws;

public class LCM_HCFServiceLocator extends org.apache.axis.client.Service implements com.ws.LCM_HCFService {

    public LCM_HCFServiceLocator() {
    }


    public LCM_HCFServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public LCM_HCFServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for LCM_HCF
    private java.lang.String LCM_HCF_address = "http://localhost:8014/Demo/services/LCM_HCF";

    public java.lang.String getLCM_HCFAddress() {
        return LCM_HCF_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String LCM_HCFWSDDServiceName = "LCM_HCF";

    public java.lang.String getLCM_HCFWSDDServiceName() {
        return LCM_HCFWSDDServiceName;
    }

    public void setLCM_HCFWSDDServiceName(java.lang.String name) {
        LCM_HCFWSDDServiceName = name;
    }

    public com.ws.LCM_HCF getLCM_HCF() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(LCM_HCF_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getLCM_HCF(endpoint);
    }

    public com.ws.LCM_HCF getLCM_HCF(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.ws.LCM_HCFSoapBindingStub _stub = new com.ws.LCM_HCFSoapBindingStub(portAddress, this);
            _stub.setPortName(getLCM_HCFWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setLCM_HCFEndpointAddress(java.lang.String address) {
        LCM_HCF_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.ws.LCM_HCF.class.isAssignableFrom(serviceEndpointInterface)) {
                com.ws.LCM_HCFSoapBindingStub _stub = new com.ws.LCM_HCFSoapBindingStub(new java.net.URL(LCM_HCF_address), this);
                _stub.setPortName(getLCM_HCFWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("LCM_HCF".equals(inputPortName)) {
            return getLCM_HCF();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.com", "LCM_HCFService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.com", "LCM_HCF"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("LCM_HCF".equals(portName)) {
            setLCM_HCFEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
