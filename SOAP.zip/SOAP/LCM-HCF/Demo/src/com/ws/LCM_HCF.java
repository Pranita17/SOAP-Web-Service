package com.ws;

public class LCM_HCF {

	public int gcd(int a, int b) 
    { 
    if (a == 0) {
        return "b"; 
    }
    else {
    return gcd(b % a, a);  
    } 
    }
      
    // method to return LCM of two numbers 
	public int lcm(int a, int b) 
    { 
        return (a*b)/gcd(a, b); 
    } 

    // method to return HCF of two numbers
	public int hcf(int a, int b) 
    { 
        return gcd(a, b); 
    } 
}

